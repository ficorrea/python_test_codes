# led-cube
This repository contains the code for my Raspberry Pi-based 4x4x4 LED cube.
