class Subtract():
    def subtract(self, x, y):
        return x - y