class Divide():
    def divide(self, x , y):
        return x / y