class Multiply():
    def multiply(self, x, y):
        return x * y