class Add():
    def add(self, x, y):
        return x + y