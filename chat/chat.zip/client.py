# -*- coding: utf-8 -*-

import socket
import time
from threading import Thread


class Cliente():
    cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    porta = None
    host = None
    mensagem = None

    def __init__(self, interface):
        self.interface = interface

    def montar(self, user, msg):
        self.mensagem = user + ' diz: ' + msg

    def conectar(self, port):
        self.porta = int(port)
        self.host = 'localhost'
        print('Conectando ao servidor...')
        try:
            self.cliente.connect((self.host, self.porta))
            self.interface.listWidget_view.addItem('Conectado ao servidor')
        except Exception as e:
            print(e)
            time.sleep(1)
            self.conectar()
        return True

    def enviar_mensagens(self):
        self.cliente.sendall(self.mensagem.encode('utf-8'))

    def recebe_mensagens(self):
        mensagem = self.cliente.recv(1024)
        msg = str(mensagem.decode('utf-8'))
        self.interface.listWidget_view.addItem(msg)

    #def recebe_tela(self):
        #mensagem = self.cliente.recv(1024).decode('utf-8')
        #mensagem = mensagem.decode('utf-8')
        # self.interface.listWidget_view.addItem('teste10')

    def iniciar_chat(self):
        self.enviar_mensagens()
        time.sleep(0.5)
        self.recebe_mensagens()
        # self.recebe_tela()

''''class ThreadEnviarMensagens(Thread):

    def __init__(self, cliente):
        #Thread.__init__(self)
        self.objetoCliente = cliente

    def enviar_mensagens(self):
        #while True:
            #print('Digite sua mensagem')
        #mensagem = input('Digite sua mensagem: ')
        mensagem = self.objetoCliente.mensagem
        print(mensagem)
            #print(self.mensagem)
        self.objetoCliente.cliente.sendall(mensagem.encode('utf-8'))
        #self.objetoCliente.cliente.close()

    def run(self):
        #while True:
        self.enviar_mensagens()
        self.objetoCliente.cliente.close()


class ThreadRecebeMensagem(Thread):

    def __init__(self, cliente):
        #Thread.__init__(self)
        self.objetoCliente = cliente

    def recebe_mensagens(self):
        #while True:
        #print('Digite sua mensagem')
        mensagem = self.objetoCliente.cliente.recv(1024)
        print(mensagem.decode('utf-8'))
        #self.objetoCliente.cliente.close()

    def run(self):
        #while True:
        self.recebe_mensagens()
        self.objetoCliente.cliente.close()'''
